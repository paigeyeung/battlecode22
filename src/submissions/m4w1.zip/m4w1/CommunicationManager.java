package m4w1;

strictfp class CommunicationManager {
    static int ALLY_ARCHON_TRACKERS_INDEX = 0; // 0-3
    static int ENEMY_ARCHON_TRACKERS_INDEX = 4; // 4-7
    static int ARCHON_RESOURCE_MANAGER_INDEX = 8; // 8-9
    static int GENERAL_STRATEGY_INDEX = 10; // 10
}
