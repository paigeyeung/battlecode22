package m4;

import battlecode.common.*;

public strictfp class RobotPlayer {
    static RobotController rc;

    public static void run(RobotController _rc) throws GameActionException {
        rc = _rc;

        GeneralManager.startingLocation = rc.getLocation();
        GeneralManager.mapWidth = rc.getMapWidth();
        GeneralManager.mapHeight = rc.getMapHeight();

        while (true) {
            GeneralManager.turnsAlive++;

            try {
                AllUnitStrategy.runAllEarly();
                switch (rc.getType()) {
                    case ARCHON:     ArchonStrategy.runArchon(); break;
                    case MINER:      MinerStrategy.runMiner(); break;
                    case BUILDER:    BuilderStrategy.runBuilder(); break;
                    case SOLDIER:    SoldierStrategy.runSoldier(); break;
                    case SAGE:       break;
                    case LABORATORY: break;
                    case WATCHTOWER: WatchtowerStrategy.runWatchtower(); break;
                }
                AllUnitStrategy.runAllLate();
                DebugManager.sanityCheck();
            } catch (GameActionException e) {
                DebugManager.log(rc.getType() + " Exception");
                e.printStackTrace();
            } catch (Exception e) {
                DebugManager.log(rc.getType() + " Exception");
                e.printStackTrace();
            } finally {
                Clock.yield();
            }
        }
    }
}
